<!--
    var pictureSource;   // picture source
    var destinationType; // sets the format of returned value 

    // Wait for PhoneGap to connect with the device
    //
    document.addEventListener("deviceready",onDeviceReady,false);

    // PhoneGap is ready to be used!
    //
    function onDeviceReady() {
        pictureSource=navigator.camera.PictureSourceType;
        destinationType=navigator.camera.DestinationType;
	if(typeof(localStorage.img)!='undefined'){
	    smallImage=document.getElementById('cameraPic');
	    smallImage.src=localStorage.img;
	    smallImage.style.display='block';
	}
    }


// SUGGESTED ON StackExchange
function onPhotoDataSuccess(imageData) { 
    localStorage.img="data:image/jpeg;base64,"+imageData;
    var smallImage = document.getElementById('cameraPic');
    smallImage.src= localStorage.img;
    smallImage.style.display = 'block'; 
}

    // A button will call this function
    //
    function capturePhoto() {
      // Take picture using device camera and retrieve image as base64-encoded string
      navigator.camera.getPicture(onPhotoDataSuccess, onFail, {sourceType: Camera.PictureSourceType.CAMERA, destinationType : Camera.DestinationType.DATA_URL, quality: 90 });
    }


    function getPhoto(source) {
      // Retrieve image file location from specified source
      navigator.camera.getPicture(onPhotoURISuccess, onFail, { quality: 50, 
        destinationType: destinationType.FILE_URI,
        sourceType: source });
    }

    // Called if something bad happens.
    // 
    function onFail(message) {
      alert('Failed because: ' + message);
    }


-->